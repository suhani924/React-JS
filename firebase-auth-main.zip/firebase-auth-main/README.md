# 🔐 React Firebase Auth App

A simple authentication app built using React and Firebase.

## 🚀 Features
- User Login
- User Registration
- Logout
- Firebase Authentication
- Responsive UI with Bootstrap

## 🛠 Tech Stack
- React
- Firebase
- Bootstrap
- JavaScript

## 📦 Installation

1. Install dependencies
npm install

2. Install Bootstrap
npm install bootstrap

3. Run project
npm run dev

## 🔑 Firebase Setup
Create a Firebase project and add your config in `firebaseConfig.js`.

## 👨‍💻 Author
Hiya Shah
