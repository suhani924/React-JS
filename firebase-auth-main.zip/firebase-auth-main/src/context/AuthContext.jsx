import { createContext, useContext, useEffect, useState } from "react";

import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signInWithPopup,
  signOut,
  onAuthStateChanged,
  updateProfile
} from "firebase/auth";

import { auth, googleProvider, githubProvider, database } from "../firebase/firebaseConfig";

import { ref, set, update } from "firebase/database";

const AuthContext = createContext();

export function useAuth() {
  return useContext(AuthContext);
}

export function AuthProvider({ children }) {

  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // REGISTER
  async function register(email, password) {

    const result = await createUserWithEmailAndPassword(auth, email, password);

    await saveUser(result.user);

    return result;
  }

  // LOGIN
  function login(email, password) {
    return signInWithEmailAndPassword(auth, email, password);
  }

  // GOOGLE LOGIN
  async function loginWithGoogle() {

    const result = await signInWithPopup(auth, googleProvider);

    await saveUser(result.user);

    return result;
  }

  // GITHUB LOGIN
  async function loginWithGithub() {

    const result = await signInWithPopup(auth, githubProvider);

    await saveUser(result.user);

    return result;
  }

  // LOGOUT
  function logout() {
    return signOut(auth);
  }

  // UPDATE PROFILE
  async function updateUserProfile(displayName, photoURL) {

    if (!auth.currentUser) return;

    // Update Firebase Auth
    await updateProfile(auth.currentUser, {
      displayName: displayName,
      photoURL: photoURL
    });

    // Update Realtime Database
    await update(ref(database, "users/" + auth.currentUser.uid), {
      name: displayName,
      photoURL: photoURL
    });

    // Reload latest user data
    await auth.currentUser.reload();

    // Update React state
    setCurrentUser(auth.currentUser);
  }

  // SAVE USER IN DATABASE
  async function saveUser(user) {

    await set(ref(database, "users/" + user.uid), {
      uid: user.uid,
      email: user.email,
      name: user.displayName || "",
      photoURL: user.photoURL || "",
      createdAt: Date.now()
    });

  }

  // AUTH STATE LISTENER
  useEffect(() => {

    const unsubscribe = onAuthStateChanged(auth, (user) => {

      setCurrentUser(user);
      setLoading(false);

    });

    return unsubscribe;

  }, []);

  const value = {
    currentUser,
    register,
    login,
    loginWithGoogle,
    loginWithGithub,
    logout,
    updateUserProfile,
    loading
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
}