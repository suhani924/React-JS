// 🔑 src/pages/ChangePassword.jsx
// Change password while logged in (requires re-authentication)

import { useState } from "react";
import { useAuth } from "../context/AuthContext";

const ChangePassword = ({ setPage }) => {
  const { changePassword, currentUser } = useAuth();

  const [form, setForm] = useState({ current: "", newPass: "", confirm: "" });
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);
  const [loading, setLoading] = useState(false);

  // GitHub/Google users don't have a password to change
  const isEmailUser = currentUser?.providerData[0]?.providerId === "password";

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    if (form.newPass.length < 6)
      return setError("New password must be at least 6 characters");
    if (form.newPass !== form.confirm)
      return setError("Passwords do not match");
    if (form.newPass === form.current)
      return setError("New password must be different from current");

    setLoading(true);
    try {
      await changePassword(form.current, form.newPass);
      setSuccess(true);
    } catch (err) {
      if (err.code === "auth/wrong-password")
        setError("Current password is incorrect");
      else if (err.code === "auth/too-many-requests")
        setError("Too many attempts. Please try again later.");
      else setError(err.message);
    }
    setLoading(false);
  };

  if (!isEmailUser) {
    return (
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          minHeight: "80vh",
          padding: "20px",
        }}
      >
        <div
          className="card fade-up"
          style={{
            maxWidth: "420px",
            width: "100%",
            textAlign: "center",
            padding: "48px 32px",
          }}
        >
          <p style={{ fontSize: "48px", marginBottom: "16px" }}>ℹ️</p>
          <h2
            style={{
              fontFamily: "Syne",
              fontSize: "20px",
              fontWeight: 700,
              color: "#fff",
              marginBottom: "12px",
            }}
          >
            Not Available
          </h2>
          <p style={{ color: "#666", fontSize: "14px", lineHeight: 1.6 }}>
            Password change is only available for email/password accounts. You
            signed in with{" "}
            <strong style={{ color: "#22c55e" }}>
              {currentUser?.providerData[0]?.providerId}
            </strong>
            .
          </p>
          <button
            onClick={() => setPage("profile")}
            className="btn-green"
            style={{ marginTop: "24px" }}
          >
            Back to Profile
          </button>
        </div>
      </div>
    );
  }

  if (success) {
    return (
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          minHeight: "80vh",
          padding: "20px",
        }}
      >
        <div
          className="card fade-up"
          style={{
            maxWidth: "420px",
            width: "100%",
            textAlign: "center",
            padding: "48px 32px",
          }}
        >
          <p style={{ fontSize: "48px", marginBottom: "16px" }}>✅</p>
          <h2
            style={{
              fontFamily: "Syne",
              fontSize: "22px",
              fontWeight: 700,
              color: "#fff",
              marginBottom: "12px",
            }}
          >
            Password Changed!
          </h2>
          <p style={{ color: "#666", fontSize: "14px" }}>
            Your password has been updated successfully.
          </p>
          <button
            onClick={() => setPage("dashboard")}
            className="btn-green"
            style={{ marginTop: "24px" }}
          >
            Go to Dashboard
          </button>
        </div>
      </div>
    );
  }

  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        minHeight: "80vh",
        padding: "20px",
      }}
    >
      <div
        className="card fade-up"
        style={{ maxWidth: "420px", width: "100%" }}
      >
        {/* Header */}
        <div style={{ textAlign: "center", marginBottom: "28px" }}>
          <div style={{ fontSize: "40px", marginBottom: "12px" }}>🔑</div>
          <h1
            style={{
              fontFamily: "Syne",
              fontSize: "24px",
              fontWeight: 800,
              color: "#fff",
            }}
          >
            Change Password
          </h1>
          <p style={{ color: "#666", fontSize: "14px", marginTop: "6px" }}>
            Enter your current and new password
          </p>
        </div>

        {error && (
          <div
            style={{
              background: "rgba(239,68,68,0.1)",
              border: "1px solid rgba(239,68,68,0.2)",
              borderRadius: "10px",
              padding: "12px",
              marginBottom: "16px",
            }}
          >
            <p style={{ color: "#f87171", fontSize: "13px" }}>❌ {error}</p>
          </div>
        )}

        <form
          onSubmit={handleSubmit}
          style={{ display: "flex", flexDirection: "column", gap: "16px" }}
        >
          <div>
            <label className="form-label">Current Password</label>
            <input
              type="password"
              value={form.current}
              onChange={(e) => {
                setForm((p) => ({ ...p, current: e.target.value }));
                setError("");
              }}
              placeholder="Your current password"
              className="form-input"
              required
            />
          </div>

          <div>
            <label className="form-label">New Password</label>
            <input
              type="password"
              value={form.newPass}
              onChange={(e) => {
                setForm((p) => ({ ...p, newPass: e.target.value }));
                setError("");
              }}
              placeholder="Min 6 characters"
              className="form-input"
              required
            />
          </div>

          <div>
            <label className="form-label">Confirm New Password</label>
            <input
              type="password"
              value={form.confirm}
              onChange={(e) => {
                setForm((p) => ({ ...p, confirm: e.target.value }));
                setError("");
              }}
              placeholder="Repeat new password"
              className="form-input"
              required
            />
          </div>

          <button type="submit" disabled={loading} className="btn-green">
            {loading ? "⏳ Updating..." : "🔑 Update Password"}
          </button>
        </form>

        <button
          onClick={() => setPage("profile")}
          style={{
            width: "100%",
            marginTop: "12px",
            padding: "10px",
            background: "transparent",
            border: "1px solid #2a2a2a",
            color: "#666",
            borderRadius: "10px",
            cursor: "pointer",
            fontSize: "13px",
            fontWeight: 600,
          }}
        >
          ← Back to Profile
        </button>
      </div>
    </div>
  );
};

export default ChangePassword;
