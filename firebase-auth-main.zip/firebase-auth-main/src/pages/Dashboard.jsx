// 🏠 src/pages/Dashboard.jsx

import { useAuth } from "../context/AuthContext";

const Dashboard = ({ setPage }) => {
  const { currentUser, userProfile, logout, loading } = useAuth();

  if (loading) {
    return <p style={{ color: "#fff" }}>Loading profile...</p>;
  }

  if (!currentUser) return null;

  const displayName =
    userProfile?.displayName || currentUser.displayName || "User";

  const avatar =
    currentUser.photoURL ||
    `https://ui-avatars.com/api/?name=${encodeURIComponent(displayName)}&background=22c55e&color=000&size=80`;

  const createdDate = userProfile?.createdAt
    ? new Date(userProfile.createdAt).toLocaleDateString("en-IN", {
        year: "numeric",
        month: "long",
        day: "numeric",
      })
    : "—";

  const handleLogout = async () => {
    await logout();
    setPage("login");
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "32px" }}>
      {/* Welcome Card */}
      <div
        className="card fade-up"
        style={{
          background: "linear-gradient(135deg,#1a2a1a,#1f2f1f)",
          border: "1px solid rgba(34,197,94,0.2)",
        }}
      >
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            flexWrap: "wrap",
            gap: "16px",
          }}
        >
          <div style={{ display: "flex", gap: "16px", alignItems: "center" }}>
            <img
              src={avatar}
              alt="avatar"
              style={{
                width: "64px",
                height: "64px",
                borderRadius: "50%",
                border: "3px solid #22c55e",
                objectFit: "cover",
              }}
            />

            <div>
              <h1
                style={{
                  fontFamily: "Syne",
                  fontSize: "26px",
                  fontWeight: 800,
                  color: "#fff",
                }}
              >
                Welcome, {displayName} 👋
              </h1>

              <p style={{ color: "#888", fontSize: "14px" }}>
                {currentUser.email}
              </p>

              <span
                style={{
                  background: currentUser.emailVerified
                    ? "rgba(34,197,94,0.15)"
                    : "rgba(234,179,8,0.15)",
                  color: currentUser.emailVerified ? "#4ade80" : "#facc15",
                  fontSize: "11px",
                  fontWeight: 600,
                  padding: "2px 10px",
                  borderRadius: "20px",
                  marginTop: "6px",
                  display: "inline-block",
                }}
              >
                {currentUser.emailVerified
                  ? "✅ Email verified"
                  : "⚠ Email not verified"}
              </span>
            </div>
          </div>

          <button onClick={() => setPage("profile")} className="btn-green">
            ✏️ Edit Profile
          </button>
        </div>
      </div>

      {/* Account Info */}
      <div className="card fade-up">
        <h2
          style={{
            fontFamily: "Syne",
            fontSize: "18px",
            fontWeight: 700,
            color: "#fff",
            marginBottom: "20px",
          }}
        >
          Account Details
        </h2>

        {[
          { label: "User ID", value: currentUser.uid },
          { label: "Display Name", value: displayName },
          { label: "Email", value: currentUser.email },
          { label: "Provider", value: currentUser.providerData[0]?.providerId },
          { label: "Account Created", value: createdDate },
        ].map(({ label, value }) => (
          <div
            key={label}
            style={{
              display: "flex",
              justifyContent: "space-between",
              padding: "12px 16px",
              background: "#171717",
              borderRadius: "10px",
              border: "1px solid #2a2a2a",
              marginBottom: "10px",
            }}
          >
            <span style={{ color: "#666", fontSize: "13px", fontWeight: 600 }}>
              {label}
            </span>

            <span
              style={{
                color: "#ddd",
                fontSize: "13px",
                maxWidth: "260px",
                overflow: "hidden",
                textOverflow: "ellipsis",
                whiteSpace: "nowrap",
              }}
            >
              {value || "—"}
            </span>
          </div>
        ))}
      </div>

      {/* Actions */}
      <div className="card fade-up">
        <h2
          style={{
            fontFamily: "Syne",
            fontSize: "18px",
            fontWeight: 700,
            color: "#fff",
            marginBottom: "16px",
          }}
        >
          Quick Actions
        </h2>

        <div style={{ display: "flex", gap: "12px", flexWrap: "wrap" }}>
          <button
            onClick={() => setPage("profile")}
            className="btn btn-secondary"
            style={{
              background: "#22C55E",
              border: "1px solid rgba(239,68,68,0.2)",
              color: "#000",
              padding: "10px 20px",
              borderRadius: "10px",
              cursor: "pointer",
              fontSize: "13px",
              fontWeight: 600,
            }}
          >
            ✏️ Edit Profile
          </button>

          <button
            onClick={() => setPage("change-password")}
            className="btn btn-secondary"
            style={{
              background: "#22C55E",
              border: "1px solid rgba(239,68,68,0.2)",
              color: "#000",
              padding: "10px 20px",
              borderRadius: "10px",
              cursor: "pointer",
              fontSize: "13px",
              fontWeight: 600,
            }}
          >
            🔑 Change Password
          </button>

          <button
            onClick={handleLogout}
            style={{
              background: "rgba(239,68,68,0.1)",
              border: "1px solid rgba(239,68,68,0.2)",
              color: "#f87171",
              padding: "10px 20px",
              borderRadius: "10px",
              cursor: "pointer",
              fontSize: "13px",
              fontWeight: 600,
            }}
          >
            🚪 Logout
          </button>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
