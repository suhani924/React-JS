// 📝 src/pages/Register.jsx
// User Registration with Email/Password + Google + GitHub

import { useState }  from 'react'
import { useAuth }   from '../context/AuthContext'

const Register = ({ setPage }) => {
  const { register, loginWithGoogle, loginWithGithub } = useAuth()

  const [form,    setForm]    = useState({ name: '', email: '', password: '', confirm: '' })
  const [error,   setError]   = useState('')
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)

  const handleChange = (e) => {
    setForm(prev => ({ ...prev, [e.target.name]: e.target.value }))
    setError('')
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')

    if (!form.name.trim())              return setError('Full name is required')
    if (form.password.length < 6)       return setError('Password must be at least 6 characters')
    if (form.password !== form.confirm) return setError('Passwords do not match')

    setLoading(true)
    try {
      await register(form.email, form.password, form.name)
      setSuccess(true)
    } catch (err) {
      if (err.code === 'auth/email-already-in-use') setError('Email is already registered')
      else if (err.code === 'auth/invalid-email')   setError('Invalid email address')
      else                                           setError(err.message)
    }
    setLoading(false)
  }

  const handleGoogle = async () => {
    setLoading(true)
    try {
      await loginWithGoogle()
      setPage('dashboard')
    } catch (err) {
      setError(err.message)
    }
    setLoading(false)
  }

  const handleGithub = async () => {
    setLoading(true)
    try {
      await loginWithGithub()
      setPage('dashboard')
    } catch (err) {
      setError(err.message)
    }
    setLoading(false)
  }

  if (success) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '80vh' }}>
        <div className="card" style={{ maxWidth: '420px', width: '100%', textAlign: 'center', padding: '48px 32px' }}>
          <p style={{ fontSize: '56px', marginBottom: '16px' }}>📧</p>
          <h2 style={{ fontFamily: 'Syne', fontSize: '22px', fontWeight: 700, color: '#fff', marginBottom: '12px' }}>
            Verify your email!
          </h2>
          <p style={{ color: '#888', fontSize: '14px', lineHeight: 1.6 }}>
            We sent a verification link to <strong style={{ color: '#22c55e' }}>{form.email}</strong>.
            Please check your inbox and click the link to activate your account.
          </p>
          <button
            onClick={() => setPage('login')}
            className="btn-green"
            style={{ marginTop: '24px' }}
          >
            Go to Login
          </button>
        </div>
      </div>
    )
  }

  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '80vh', padding: '20px' }}>
      <div className="card fade-up" style={{ maxWidth: '440px', width: '100%' }}>

        {/* Header */}
        <div style={{ textAlign: 'center', marginBottom: '28px' }}>
          <div style={{ fontSize: '40px', marginBottom: '12px' }}>🚀</div>
          <h1 style={{ fontFamily: 'Syne', fontSize: '26px', fontWeight: 800, color: '#fff' }}>Create Account</h1>
          <p style={{ color: '#666', fontSize: '14px', marginTop: '6px' }}>Join us today — it's free!</p>
        </div>

        {/* Social Buttons */}
        <div style={{ display: 'flex', gap: '10px', marginBottom: '20px' }}>
          <button onClick={handleGoogle} disabled={loading} style={{
            flex: 1, padding: '10px', borderRadius: '10px',
            background: '#222', border: '1px solid #333',
            color: '#fff', fontSize: '13px', fontWeight: 600,
            cursor: 'pointer', display: 'flex', alignItems: 'center',
            justifyContent: 'center', gap: '8px',
          }}>
            <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" width="16" alt="Google" />
            Google
          </button>
          <button onClick={handleGithub} disabled={loading} style={{
            flex: 1, padding: '10px', borderRadius: '10px',
            background: '#222', border: '1px solid #333',
            color: '#fff', fontSize: '13px', fontWeight: 600,
            cursor: 'pointer', display: 'flex', alignItems: 'center',
            justifyContent: 'center', gap: '8px',
          }}>
            <span style={{ fontSize: '16px' }}>🐙</span> GitHub
          </button>
        </div>

        {/* Divider */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '20px' }}>
          <div style={{ flex: 1, height: '1px', background: '#2a2a2a' }} />
          <span style={{ color: '#555', fontSize: '12px' }}>or register with email</span>
          <div style={{ flex: 1, height: '1px', background: '#2a2a2a' }} />
        </div>

        {/* Error */}
        {error && (
          <div style={{ background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.2)', borderRadius: '10px', padding: '12px', marginBottom: '16px' }}>
            <p style={{ color: '#f87171', fontSize: '13px' }}>❌ {error}</p>
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>

          <div>
            <label className="form-label">Full Name</label>
            <input name="name" value={form.name} onChange={handleChange}
              placeholder="John Doe" className="form-input" required />
          </div>

          <div>
            <label className="form-label">Email</label>
            <input name="email" type="email" value={form.email} onChange={handleChange}
              placeholder="john@example.com" className="form-input" required />
          </div>

          <div>
            <label className="form-label">Password</label>
            <input name="password" type="password" value={form.password} onChange={handleChange}
              placeholder="Min 6 characters" className="form-input" required />
          </div>

          <div>
            <label className="form-label">Confirm Password</label>
            <input name="confirm" type="password" value={form.confirm} onChange={handleChange}
              placeholder="Repeat password" className="form-input" required />
          </div>

          <button type="submit" disabled={loading} className="btn-green" style={{ marginTop: '4px' }}>
            {loading ? '⏳ Creating Account...' : '🚀 Create Account'}
          </button>

        </form>

        {/* Login link */}
        <p style={{ textAlign: 'center', fontSize: '13px', color: '#666', marginTop: '20px' }}>
          Already have an account?{' '}
          <span onClick={() => setPage('login')} style={{ color: '#22c55e', cursor: 'pointer', fontWeight: 600 }}>
            Sign in
          </span>
        </p>

      </div>
    </div>
  )
}

export default Register