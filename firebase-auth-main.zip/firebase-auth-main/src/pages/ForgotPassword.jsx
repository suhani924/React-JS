// 🔓 src/pages/ForgotPassword.jsx
// Sends password reset email via Firebase

import { useState } from 'react'
import { useAuth }  from '../context/AuthContext'

const ForgotPassword = ({ setPage }) => {
  const { resetPassword } = useAuth()

  const [email,   setEmail]   = useState('')
  const [error,   setError]   = useState('')
  const [success, setSuccess] = useState(false)
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    setLoading(true)
    try {
      await resetPassword(email)
      setSuccess(true)
    } catch (err) {
      if (err.code === 'auth/user-not-found') setError('No account found with this email')
      else if (err.code === 'auth/invalid-email') setError('Invalid email address')
      else setError(err.message)
    }
    setLoading(false)
  }

  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '80vh', padding: '20px' }}>
      <div className="card fade-up" style={{ maxWidth: '420px', width: '100%' }}>

        {/* Header */}
        <div style={{ textAlign: 'center', marginBottom: '28px' }}>
          <div style={{ fontSize: '40px', marginBottom: '12px' }}>🔓</div>
          <h1 style={{ fontFamily: 'Syne', fontSize: '24px', fontWeight: 800, color: '#fff' }}>Reset Password</h1>
          <p style={{ color: '#666', fontSize: '14px', marginTop: '6px' }}>
            Enter your email and we'll send you a reset link
          </p>
        </div>

        {success ? (
          <div style={{ textAlign: 'center' }}>
            <div style={{ background: 'rgba(34,197,94,0.1)', border: '1px solid rgba(34,197,94,0.2)', borderRadius: '12px', padding: '20px', marginBottom: '20px' }}>
              <p style={{ color: '#4ade80', fontSize: '14px', fontWeight: 600 }}>
                ✅ Reset link sent to <strong>{email}</strong>
              </p>
              <p style={{ color: '#666', fontSize: '12px', marginTop: '6px' }}>
                Check your inbox and follow the instructions.
              </p>
            </div>
            <button onClick={() => setPage('login')} className="btn-green">
              Back to Login
            </button>
          </div>
        ) : (
          <>
            {error && (
              <div style={{ background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.2)', borderRadius: '10px', padding: '12px', marginBottom: '16px' }}>
                <p style={{ color: '#f87171', fontSize: '13px' }}>❌ {error}</p>
              </div>
            )}

            <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
              <div>
                <label className="form-label">Email Address</label>
                <input
                  type="email"
                  value={email}
                  onChange={e => { setEmail(e.target.value); setError('') }}
                  placeholder="john@example.com"
                  className="form-input"
                  required
                />
              </div>
              <button type="submit" disabled={loading} className="btn-green">
                {loading ? '⏳ Sending...' : '📧 Send Reset Link'}
              </button>
            </form>

            <p style={{ textAlign: 'center', fontSize: '13px', color: '#666', marginTop: '20px' }}>
              Remember your password?{' '}
              <span onClick={() => setPage('login')} style={{ color: '#22c55e', cursor: 'pointer', fontWeight: 600 }}>
                Sign in
              </span>
            </p>
          </>
        )}

      </div>
    </div>
  )
}

export default ForgotPassword