// 🔑 src/pages/Login.jsx
// Login with Email/Password + Google + GitHub

import { useState } from "react";
import { useAuth } from "../context/AuthContext";

const Login = ({ setPage }) => {
  const { login, loginWithGoogle, loginWithGithub } = useAuth();

  const [form, setForm] = useState({ email: "", password: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
    setError("");
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const userCredential = await login(form.email, form.password);
      const user = userCredential.user;

      // 🚨 Check email verification
      if (!user.emailVerified) {
        setError(
          "❌ Please verify your email before logging in. Check your inbox.",
        );
        setLoading(false);
        return;
      }

      setPage("dashboard");
    } catch (err) {
      if (err.code === "auth/user-not-found")
        setError("No account found with this email. Please register first.");
      else if (err.code === "auth/wrong-password")
        setError("Incorrect password. Please try again.");
      else if (err.code === "auth/invalid-email")
        setError("Invalid email address format.");
      else if (err.code === "auth/user-disabled")
        setError("This account has been disabled.");
      else if (err.code === "auth/too-many-requests")
        setError("Too many failed attempts. Please wait and try again.");
      else if (err.code === "auth/network-request-failed")
        setError("Network error. Check your internet connection.");
      else if (err.code === "auth/email-not-verified")
        setError("Please verify your email before logging in.");
      else setError(`Error: ${err.code} — ${err.message}`);
    }

    setLoading(false);
  };

  const handleGoogle = async () => {
    setLoading(true);
    try {
      await loginWithGoogle();
      setPage("dashboard");
    } catch (err) {
      setError(err.message);
    }
    setLoading(false);
  };

  const handleGithub = async () => {
    setLoading(true);
    try {
      await loginWithGithub();
      setPage("dashboard");
    } catch (err) {
      setError(err.message);
    }
    setLoading(false);
  };

  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        minHeight: "80vh",
        padding: "20px",
      }}
    >
      <div
        className="card fade-up"
        style={{ maxWidth: "420px", width: "100%" }}
      >
        {/* Header */}
        <div style={{ textAlign: "center", marginBottom: "28px" }}>
          <div style={{ fontSize: "40px", marginBottom: "12px" }}>👋</div>
          <h1
            style={{
              fontFamily: "Syne",
              fontSize: "26px",
              fontWeight: 800,
              color: "#fff",
            }}
          >
            Welcome Back
          </h1>
          <p style={{ color: "#666", fontSize: "14px", marginTop: "6px" }}>
            Sign in to your account
          </p>
        </div>

        {/* Social Buttons */}
        <div style={{ display: "flex", gap: "10px", marginBottom: "20px" }}>
          <button
            onClick={handleGoogle}
            disabled={loading}
            style={{
              flex: 1,
              padding: "10px",
              borderRadius: "10px",
              background: "#222",
              border: "1px solid #333",
              color: "#fff",
              fontSize: "13px",
              fontWeight: 600,
              cursor: "pointer",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: "8px",
            }}
          >
            <img
              src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg"
              width="16"
              alt="Google"
            />
            Google
          </button>
          <button
            onClick={handleGithub}
            disabled={loading}
            style={{
              flex: 1,
              padding: "10px",
              borderRadius: "10px",
              background: "#222",
              border: "1px solid #333",
              color: "#fff",
              fontSize: "13px",
              fontWeight: 600,
              cursor: "pointer",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: "8px",
            }}
          >
            <span style={{ fontSize: "16px" }}>🐙</span> GitHub
          </button>
        </div>

        {/* Divider */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: "12px",
            marginBottom: "20px",
          }}
        >
          <div style={{ flex: 1, height: "1px", background: "#2a2a2a" }} />
          <span style={{ color: "#555", fontSize: "12px" }}>
            or sign in with email
          </span>
          <div style={{ flex: 1, height: "1px", background: "#2a2a2a" }} />
        </div>

        {/* Error */}
        {error && (
          <div
            style={{
              background: "rgba(239,68,68,0.1)",
              border: "1px solid rgba(239,68,68,0.2)",
              borderRadius: "10px",
              padding: "12px",
              marginBottom: "16px",
            }}
          >
            <p style={{ color: "#f87171", fontSize: "13px" }}>❌ {error}</p>
          </div>
        )}

        {/* Form */}
        <form
          onSubmit={handleSubmit}
          style={{ display: "flex", flexDirection: "column", gap: "14px" }}
        >
          <div>
            <label className="form-label">Email</label>
            <input
              name="email"
              type="email"
              value={form.email}
              onChange={handleChange}
              placeholder="john@example.com"
              className="form-input"
              required
            />
          </div>

          <div>
            <label className="form-label">Password</label>
            <input
              name="password"
              type="password"
              value={form.password}
              onChange={handleChange}
              placeholder="Your password"
              className="form-input"
              required
            />
          </div>

          {/* Forgot password */}
          <div style={{ textAlign: "right", marginTop: "-6px" }}>
            <span
              onClick={() => setPage("forgot")}
              style={{
                color: "#22c55e",
                fontSize: "12px",
                cursor: "pointer",
                fontWeight: 600,
              }}
            >
              Forgot password?
            </span>
          </div>

          <button type="submit" disabled={loading} className="btn-green">
            {loading ? "⏳ Signing in..." : "🔑 Sign In"}
          </button>
        </form>

        {/* Register link */}
        <p
          style={{
            textAlign: "center",
            fontSize: "13px",
            color: "#666",
            marginTop: "20px",
          }}
        >
          Don't have an account?{" "}
          <span
            onClick={() => setPage("register")}
            style={{ color: "#22c55e", cursor: "pointer", fontWeight: 600 }}
          >
            Sign up
          </span>
        </p>
      </div>
    </div>
  );
};

export default Login;
