import { useState, useEffect } from "react";
import { useAuth } from "../context/AuthContext";

const Profile = ({ setPage }) => {
  const { currentUser, updateUserProfile } = useAuth();

  const [form, setForm] = useState({
    displayName: "",
    photoURL: ""
  });

  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  useEffect(() => {
    if (currentUser) {
      setForm({
        displayName: currentUser.displayName || "",
        photoURL: currentUser.photoURL || ""
      });
    }
  }, [currentUser]);

  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!form.displayName.trim()) {
      setMessage("❌ Display name is required");
      return;
    }

    setLoading(true);

    try {
      await updateUserProfile(
        form.displayName.trim(),
        form.photoURL.trim()
      );

      setMessage("✅ Profile updated successfully");
    } catch (err) {
      setMessage("❌ " + err.message);
    }

    setLoading(false);
  };

  const avatar =
    form.photoURL ||
    currentUser?.photoURL ||
    `https://ui-avatars.com/api/?name=${encodeURIComponent(
      form.displayName || "User"
    )}&background=22c55e&color=000&size=80`;

  return (
    <div style={container}>
      <div style={card}>

        <div style={{ textAlign: "center", marginBottom: 20 }}>
          <img src={avatar} alt="avatar" style={avatarStyle} />

          <h2 style={{ color: "#fff" }}>Edit Profile</h2>
          <p style={{ color: "#777", fontSize: 13 }}>
            {currentUser?.email}
          </p>
        </div>

        {message && (
          <p style={{ color: "#4ade80", textAlign: "center" }}>
            {message}
          </p>
        )}

        <form onSubmit={handleSubmit} style={formStyle}>

          <input
            name="displayName"
            value={form.displayName}
            onChange={handleChange}
            placeholder="Display Name"
            style={input}
          />

          <input
            name="photoURL"
            value={form.photoURL}
            onChange={handleChange}
            placeholder="Profile Image URL"
            style={input}
          />

          <button
            type="submit"
            disabled={loading}
            style={saveBtn}
          >
            {loading ? "Updating..." : "💾 Save Changes"}
          </button>

        </form>

        <div style={bottomButtons}>
          <button
            onClick={() => setPage("change-password")}
            style={secondaryBtn}
          >
            🔑 Change Password
          </button>

          <button
            onClick={() => setPage("dashboard")}
            style={secondaryBtn}
          >
            ← Back
          </button>
        </div>

      </div>
    </div>
  );
};

export default Profile;


/* ---------- Styles ---------- */

const container = {
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
  minHeight: "80vh",
  padding: "20px"
};

const card = {
  background: "#181818",
  border: "1px solid #2a2a2a",
  borderRadius: "16px",
  padding: "30px",
  width: "100%",
  maxWidth: "450px"
};

const avatarStyle = {
  width: "80px",
  height: "80px",
  borderRadius: "50%",
  border: "3px solid #22c55e",
  marginBottom: "10px"
};

const formStyle = {
  display: "flex",
  flexDirection: "column",
  gap: "12px"
};

const input = {
  padding: "10px",
  borderRadius: "8px",
  border: "1px solid #333",
  background: "#111",
  color: "#fff"
};

const saveBtn = {
  padding: "12px",
  borderRadius: "10px",
  border: "none",
  background: "#22c55e",
  color: "#fff",
  fontWeight: "600",
  cursor: "pointer"
};

const bottomButtons = {
  display: "flex",
  gap: "10px",
  marginTop: "15px"
};

const secondaryBtn = {
  flex: 1,
  padding: "10px",
  borderRadius: "10px",
  background: "#222",
  border: "1px solid #333",
  color: "#fff",
  cursor: "pointer"
};