import { useAuth } from "../context/AuthContext";

const Navbar = ({ page, setPage }) => {
  const { currentUser, logout } = useAuth();

  const handleLogout = async () => {
    await logout();
    setPage("login");
  };

  return (
    <nav
      style={{
        background: "#1a1a1a",
        borderBottom: "1px solid #2a2a2a",
        position: "sticky",
        top: 0,
        zIndex: 50,
      }}
    >
      <div
        className="page-wrapper"
        style={{
          height: "64px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
        }}
      >
        {/* Logo */}
        <div
          onClick={() => setPage(currentUser ? "dashboard" : "login")}
          style={{
            display: "flex",
            alignItems: "center",
            gap: "10px",
            cursor: "pointer",
          }}
        >
          <div
            style={{
              width: "38px",
              height: "38px",
              borderRadius: "10px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontSize: "40px",
            }}
          >
            🔐
          </div>

          <span
            style={{
              fontFamily: "Syne",
              fontWeight: 800,
              fontSize: "25px",
              color: "#fff",
            }}
          >
            AuthApp
          </span>
        </div>

        <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
          {currentUser ? (
            <>
              <span>
                {currentUser.displayName || currentUser.email}
              </span>

              {/* Dashboard */}
              <button
                onClick={() => setPage("dashboard")}
                style={{
                  background: page === "dashboard" ? "#22c55e" : "transparent",
                  color: page === "dashboard" ? "#000" : "#888",
                  border: "none",
                  borderRadius: "8px",
                  padding: "7px 14px",
                  fontSize: "13px",
                  fontWeight: 600,
                  cursor: "pointer",
                }}
              >
                Dashboard
              </button>

              {/* Logout */}
              <button
                onClick={handleLogout}
                style={{
                  background: "rgba(239,68,68,0.12)",
                  color: "#f87171",
                  border: "none",
                  borderRadius: "8px",
                  padding: "7px 14px",
                  fontSize: "13px",
                  fontWeight: 600,
                  cursor: "pointer",
                }}
              >
                Logout
              </button>
            </>
          ) : (
            <>
              {/* Login */}
              <button
                onClick={() => setPage("login")}
                style={{
                  background: page === "login" ? "#22c55e" : "transparent",
                  color: page === "login" ? "#000" : "#888",
                  border: "none",
                  borderRadius: "8px",
                  padding: "7px 14px",
                  fontSize: "13px",
                  fontWeight: 600,
                  cursor: "pointer",
                }}
              >
                Login
              </button>

              {/* Sign Up */}
              <button
                onClick={() => setPage("register")}
                style={{
                  background: "#22c55e",
                  color: "#000",
                  border: "none",
                  borderRadius: "8px",
                  padding: "7px 14px",
                  fontSize: "13px",
                  fontWeight: 700,
                  cursor: "pointer",
                }}
              >
                Sign Up
              </button>
            </>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
