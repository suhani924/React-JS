import { useEffect } from "react"
import { useAuth } from "../context/AuthContext"

const ProtectedRoute = ({ children, setPage }) => {

  const { currentUser, loading } = useAuth()

  useEffect(() => {
    if (!loading && !currentUser) {
      setPage("login")
    }
  }, [currentUser, loading, setPage])

  if (loading) return null

  if (!currentUser) return null

  return children
}

export default ProtectedRoute