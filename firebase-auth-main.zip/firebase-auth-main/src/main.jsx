// 🚀 src/main.jsx

import React    from 'react'
import ReactDOM from 'react-dom/client'
import { AuthProvider } from './context/AuthContext'
import App from './App.jsx'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    {/* AuthProvider wraps entire app — every component can use useAuth() */}
    <AuthProvider>
      <App />
    </AuthProvider>
  </React.StrictMode>
)