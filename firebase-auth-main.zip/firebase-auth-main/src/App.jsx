import { useEffect }       from 'react'
import { useAuth }         from './context/AuthContext'
import Navbar              from './components/Navbar.jsx'
import ProtectedRoute      from './components/ProtectedRoute.jsx'
import Login               from './pages/Login.jsx'
import Register            from './pages/Register.jsx'
import ForgotPassword      from './pages/ForgotPassword.jsx'
import Dashboard           from './pages/Dashboard.jsx'
import Profile             from './pages/Profile.jsx'
import ChangePassword      from './pages/ChangePassword.jsx'
import { useState }        from 'react'

const App = () => {
  const { currentUser } = useAuth()
  const [page, setPage] = useState('login')

  // Auto redirect: if logged in → dashboard, if logged out → login
  useEffect(() => {
    if (currentUser) {
      if (page === 'login' || page === 'register' || page === 'forgot') {
        setPage('dashboard')
      }
    } else {
      if (page === 'dashboard' || page === 'profile' || page === 'change-password') {
        setPage('login')
      }
    }
  }, [currentUser])

  return (
    <div style={{ minHeight: '100vh', background: '#111111' }}>
      <Navbar page={page} setPage={setPage} />
      <div className="page-wrapper" style={{ paddingTop: '40px', paddingBottom: '60px' }}>

        {/* Public Pages */}
        {page === 'login'    && <Login          setPage={setPage} />}
        {page === 'register' && <Register       setPage={setPage} />}
        {page === 'forgot'   && <ForgotPassword setPage={setPage} />}

        {/* Protected Pages — redirect to login if not authenticated */}
        {page === 'dashboard' && (
          <ProtectedRoute setPage={setPage}>
            <Dashboard setPage={setPage} />
          </ProtectedRoute>
        )}
        {page === 'profile' && (
          <ProtectedRoute setPage={setPage}>
            <Profile setPage={setPage} />
          </ProtectedRoute>
        )}
        {page === 'change-password' && (
          <ProtectedRoute setPage={setPage}>
            <ChangePassword setPage={setPage} />
          </ProtectedRoute>
        )}

      </div>
    </div>
  )
}

export default App