import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider, GithubAuthProvider } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getDatabase } from "firebase/database";

const firebaseConfig = {
  apiKey: "AIzaSyA04rOw3mgYs-JSX7nrBOL4mPkUsZPUutw",
  authDomain: "fir-auth-ae3e7.firebaseapp.com",
  databaseURL: "https://fir-auth-ae3e7-default-rtdb.firebaseio.com",
  projectId: "fir-auth-ae3e7",
  storageBucket: "fir-auth-ae3e7.firebasestorage.app",
  messagingSenderId: "570755611445",
  appId: "1:570755611445:web:dae8f4a9d647af9910ea7c",
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const firestore = getFirestore(app);
export const database = getDatabase(app);

export const googleProvider = new GoogleAuthProvider();
export const githubProvider = new GithubAuthProvider();

export default app;