# 📡 API Hunter – React.js Project

API Hunter is a React.js web app that fetches and displays data from a public API.  
It helps students learn API integration, React hooks, and dynamic UI rendering.

## 🚀 Features
- API data fetching
- Search functionality
- Loading & error handling
- Responsive UI

## 🛠 Tech Stack
- React.js
- JavaScript
- HTML5
- CSS3

## 🌐 API Used
Fake Store API  
https://fakestoreapi.com/products

## ▶ How To Run
```bash
npm install
npm run dev
```

## 📸 Screenshots
<img width="564" height="698" alt="image" src="https://github.com/user-attachments/assets/8c3866bf-eb3e-4c2c-a5bb-7916ed69c682" />

