const Card = ({ item }) => {
  return (
    <div className="card">
      <div className="img-box">
        <img src={item.image} alt={item.title} />
      </div>

      <div className="card-body">
        <h3>{item.title}</h3>
        <p className="price">₹ {item.price}</p>
        <button className="btn">View</button>
      </div>
    </div>
  );
};

export default Card;