import { useEffect, useState } from "react";
import Search from "../components/Search";
import Card from "../components/Card";
import Loader from "../components/Loader";

const Home = () => {
  const [products, setProducts] = useState([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const fetchData = async () => {
    try {
      setLoading(true);
      setError("");
      const res = await fetch("https://fakestoreapi.com/products");
      const data = await res.json();
      setProducts(data);
    } catch (err) {
      setError("Failed to fetch data");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const filteredData = products.filter((item) =>
    item.title.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="container">
      <h1>📡 API Hunter</h1>

      <Search search={search} setSearch={setSearch} />

      {loading && <Loader />}
      {error && <p className="error">{error}</p>}

      <div className="grid">
        {filteredData.length > 0 ? (
          filteredData.map((item) => <Card key={item.id} item={item} />)
        ) : (
          !loading && <p>No data found</p>
        )}
      </div>
    </div>
  );
};

export default Home;