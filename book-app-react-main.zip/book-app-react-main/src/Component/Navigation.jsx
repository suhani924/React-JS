import { Navbar, Nav, Container } from "react-bootstrap";
import { Link } from "react-router-dom";

function Navigation() {
  return (
    <Navbar bg="light">
      <Container>

        <Navbar.Brand as={Link} to="/">Book App</Navbar.Brand>

        <Nav>

          <Nav.Link as={Link} to="/">Home</Nav.Link>

          <Nav.Link as={Link} to="/addbook">Add Book</Nav.Link>

          <Nav.Link as={Link} to="/viewbook">View Book</Nav.Link>

        </Nav>

      </Container>
    </Navbar>
  );
}

export default Navigation;