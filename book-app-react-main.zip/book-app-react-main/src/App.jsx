import { useState } from "react";
import { Routes, Route } from "react-router-dom";

import Navigation from "./Component/Navigation";
import Home from "./Pages/Home";
import Add from "./Pages/Add";
import View from "./Pages/View";
import BookDetail from "./Pages/BookDetail";

function App() {

  const initialBooks = [
    {
      id: 1,
      title: "The Millionaire Next Door",
      author: "William D. Danko Ph.D",
      publisher: "Harper Business",
      price: 450,
      type: "Finance",
      imgurl: "https://m.media-amazon.com/images/I/410-4I+i9-L._SY445_SX342_FMwebp_.jpg",
      details:
        "The bestselling The Millionaire Next Door identifies seven common traits that show up again and again among those who have accumulated wealth."
    },
    {
      id: 2,
      title: "Think and Grow Rich",
      author: "Napoleon Hill",
      publisher: "Fingerprint",
      price: 350,
      type: "Self Help",
      imgurl: "https://m.media-amazon.com/images/I/61IxJuRI39L._SL1000_.jpg",
      details:
        "Think and Grow Rich has been called the Granddaddy of All Motivational Literature."
    },
    {
      id: 3,
      title: "Rich Dad Poor Dad",
      author: "Robert Kiyosaki",
      publisher: "Plata Publishing",
      price: 399,
      type: "Finance",
      imgurl: "https://m.media-amazon.com/images/I/81BE7eeKzAL._SL1500_.jpg",
      details:
        "While there is a milestone to commemorate — preserving the integrity of the original content is testimony to the fact that this book has truly stood the test of time."
    }
  ];

  const [addedBooks, setAddedBooks] = useState([]);

  const addNewBook = (book) => {
    setAddedBooks([...addedBooks, book]);
  };

  const updateBooks = (books) => {
    setAddedBooks(books);
  };

  return (
    <>
      <Navigation />

      <div className="container mt-4">

        <Routes>

          <Route
            path="/"
            element={<Home initialBooks={initialBooks} addedBooks={addedBooks} />}
          />

          <Route
            path="/AddBook"
            element={<Add addNewBook={addNewBook} />}
          />

          <Route
            path="/ViewBook"
            element={<View books={addedBooks} updateBooks={updateBooks} />}
          />

          <Route
            path="/book/:id"
            element={<BookDetail initialBooks={initialBooks} addedBooks={addedBooks} />}
          />

          <Route path="*" element={<h1>Page Not Found</h1>} />

        </Routes>

      </div>
    </>
  );
}

export default App;