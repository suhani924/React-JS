function View() {
  return <h1>Edit Book Page</h1>;
}

export default View;