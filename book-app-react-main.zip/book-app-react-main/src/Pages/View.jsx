import { useState } from "react";
import { Table, Button, Modal, Form, Row, Col } from "react-bootstrap";

function View({ books, updateBooks }) {

  const [showModal, setShowModal] = useState(false);
  const [editBook, setEditBook] = useState(null);
  const [search, setSearch] = useState("");
  const [sortOption, setSortOption] = useState("");

  const handleDelete = (id) => {
    if (window.confirm("Delete this book?")) {
      updateBooks(books.filter(b => b.id !== id));
    }
  };

  const handleEdit = (book) => {
    setEditBook(book);
    setShowModal(true);
  };

  const handleChange = (e) => {
    setEditBook({ ...editBook, [e.target.name]: e.target.value });
  };

  const handleSave = () => {
    updateBooks(
      books.map(b => (b.id === editBook.id ? editBook : b))
    );
    setShowModal(false);
  };

  let filteredBooks = books.filter(b =>
    b.title.toLowerCase().includes(search.toLowerCase()) ||
    b.author.toLowerCase().includes(search.toLowerCase()) ||
    b.publisher.toLowerCase().includes(search.toLowerCase())
  );

 
  if (sortOption === "title-asc")
    filteredBooks.sort((a, b) => a.title.localeCompare(b.title));

  else if (sortOption === "title-desc")
    filteredBooks.sort((a, b) => b.title.localeCompare(a.title));

  else if (sortOption === "price-asc")
    filteredBooks.sort((a, b) => Number(a.price) - Number(b.price));

  else if (sortOption === "price-desc")
    filteredBooks.sort((a, b) => Number(b.price) - Number(a.price));

  return (
    <>
      <h2 className="mb-4">View Books</h2>

    
      <Row className="mb-3">
        <Col md={6}>
          <Form.Control
            placeholder="Search Book..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </Col>

        <Col md={4}>
          <Form.Select
            value={sortOption}
            onChange={(e) => setSortOption(e.target.value)}
          >
            <option value="">Sort By</option>
            <option value="title-asc">Title A → Z</option>
            <option value="title-desc">Title Z → A</option>
            <option value="price-asc">Price Low → High</option>
            <option value="price-desc">Price High → Low</option>
          </Form.Select>
        </Col>
      </Row>

     
      <Table striped bordered hover>
        <thead>
          <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Author</th>
            <th>Publisher</th>
            <th>Price</th>
            <th>Type</th>
            <th>Image</th>
            <th>Actions</th>
          </tr>
        </thead>

        <tbody>
          {filteredBooks.map((b, index) => (
            <tr key={b.id}>
              <td>{index + 1}</td>
              <td>{b.title}</td>
              <td>{b.author}</td>
              <td>{b.publisher}</td>
              <td>{b.price}</td>
              <td>{b.type}</td>

              <td>
                <img src={b.imgurl} alt="" style={{ width: "70px" }} />
              </td>

              <td>
                <Button
                  variant="warning"
                  size="sm"
                  onClick={() => handleEdit(b)}
                >
                  Edit
                </Button>{" "}
                <Button
                  variant="danger"
                  size="sm"
                  onClick={() => handleDelete(b.id)}
                >
                  Delete
                </Button>
              </td>
            </tr>
          ))}
        </tbody>
      </Table>


      {editBook && (
        <Modal show={showModal} onHide={() => setShowModal(false)}>
          <Modal.Header closeButton>
            <Modal.Title>Edit Book</Modal.Title>
          </Modal.Header>

          <Modal.Body>
            <Form>

              <Form.Group className="mb-3">
                <Form.Label>ID</Form.Label>
                <Form.Control
                  name="id"
                  value={editBook.id}
                  onChange={handleChange}
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Title</Form.Label>
                <Form.Control
                  name="title"
                  value={editBook.title}
                  onChange={handleChange}
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Author</Form.Label>
                <Form.Control
                  name="author"
                  value={editBook.author}
                  onChange={handleChange}
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Publisher</Form.Label>
                <Form.Control
                  name="publisher"
                  value={editBook.publisher}
                  onChange={handleChange}
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Price</Form.Label>
                <Form.Control
                  name="price"
                  type="number"
                  value={editBook.price}
                  onChange={handleChange}
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Type</Form.Label>
                <Form.Control
                  name="type"
                  value={editBook.type}
                  onChange={handleChange}
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Image URL</Form.Label>
                <Form.Control
                  name="imgurl"
                  value={editBook.imgurl}
                  onChange={handleChange}
                />
              </Form.Group>

            </Form>
          </Modal.Body>

          <Modal.Footer>
            <Button
              variant="secondary"
              onClick={() => setShowModal(false)}
            >
              Close
            </Button>

            <Button
              variant="success"
              onClick={handleSave}
            >
              Save Changes
            </Button>
          </Modal.Footer>
        </Modal>
      )}
    </>
  );
}

export default View;