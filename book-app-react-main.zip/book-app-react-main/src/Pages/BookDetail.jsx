import { useParams } from "react-router-dom";
import { Container, Row, Col, Card, Button } from "react-bootstrap";
import { useState } from "react";

function BookDetail({ initialBooks, addedBooks }) {
  const { id } = useParams();

  const books = [...initialBooks, ...addedBooks];
  const book = books.find((b) => b.id.toString() === id);

  const [qty, setQty] = useState(0);

  const increaseQty = () => setQty(qty + 1);
  const decreaseQty = () => {
    if (qty > 0) setQty(qty - 1);
  };

  if (!book) return <h2>Book Not Found</h2>;

  return (
    <Container className="mt-5">
      <Card className="shadow p-4">
        <Row>
        
          <Col md={4} className="text-center">
            <img
              src={book.imgurl}
              alt={book.title}
              style={{
                width: "100%",
                maxHeight: "420px",
                objectFit: "cover",
                borderRadius: "10px",
              }}
            />
          </Col>

          <Col md={8}>
            <h2 className="mb-3">{book.title}</h2>
            <p><strong>Author:</strong> {book.author}</p>
            <p><strong>Publisher:</strong> {book.publisher || "-"}</p>
            <p><strong>Type:</strong> {book.type || "-"}</p>
            <h4 style={{ color: "green", marginTop: "10px" }}>₹ {book.price || "-"}</h4>
            <hr />
            <p style={{ lineHeight: "1.7" }}>{book.details}</p>

           
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: "15px",
                marginTop: "25px",
              }}
            >
              <Button
                variant="dark"
                style={{ width: "40px" }}
                onClick={decreaseQty}
              >
                -
              </Button>

              <h5
                style={{
                  margin: 0,
                  minWidth: "30px",
                  textAlign: "center",
                  fontWeight: "600",
                  color: "black",
                }}
              >
                {qty}
              </h5>

              <Button
                variant="dark"
                style={{ width: "40px" }}
                onClick={increaseQty}
              >
                +
              </Button>

              <Button
                variant="success"
                style={{ marginLeft: "20px", padding: "0 20px" }}
              >
                Add To Cart
              </Button>
            </div>
          </Col>
        </Row>
      </Card>
    </Container>
  );
}

export default BookDetail;