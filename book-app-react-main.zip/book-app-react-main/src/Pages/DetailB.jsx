import { useParams, Link } from "react-router-dom";
import { Container, Button } from "react-bootstrap";

function DetailB() {
  const { id } = useParams();

  
  const books = [
    {
      id: 1,
      imgurl: "https://m.media-amazon.com/images/I/410-4I+i9-L._SY445_SX342_FMwebp_.jpg",
      title: "The Millionaire Next Door",
      author: "William D. Danko Ph.D",
      details: "The New 2018 ebook best selling series has begun! William D. Danko's True Prosperity ~ Takes More Than Money. Enter the new title and get your copy today. The bestselling The Millionaire Next Door identifies seven common traits that show up again and again among those who have accumulated wealth. Most of the truly wealthy in this country don't live in Beverly Hills or on Park Avenue—they live next door. This new edition, the first since 1998, includes a new foreword for the twenty-first century by Dr. Thomas J. Stanley."
    },
    {
      id: 2,
      imgurl: "https://m.media-amazon.com/images/I/61IxJuRI39L._SL1000_.jpg",
      title: "Think and Grow Rich",
      author: "James Clear",
      details: "Think and Grow Rich has been called the “Granddaddy of All Motivational Literature.” It was the first book to boldly ask, “What makes a winner?” The man who asked and listened for the answer, Napoleon Hill, is now counted in the top ranks of the world's winners himself."
    },
    {
      id: 3,
      imgurl: "https://m.media-amazon.com/images/I/81BE7eeKzAL._SL1500_.jpg",
      title: "Rich Dad Poor Dad",
      author: "Robert Kiyosaki",
      details: "While there is a milestone to commemorate — and a new section in the book on Why Milestones Are Important — preserving the integrity of the original content is testimony to the fact that this book has truly stood the test of time."
    },
  ];

  const book = books.find((b) => b.id === parseInt(id));

  if (!book) return <Container className="mt-4"><h2>Book Not Found</h2></Container>;

  return (
    <Container className="mt-4">
      <h2>{book.title}</h2>
      <img src={book.imgurl} style={{ width: "50%", maxHeight: "400px", objectFit: "cover", marginBottom: "15px" }} />
      <p><strong>Author:</strong> {book.author}</p>
      <p>{book.details}</p>
      <Link to="/" className="btn btn-primary mt-2">Back to Home</Link>
    </Container>
  );
}

export default DetailB;