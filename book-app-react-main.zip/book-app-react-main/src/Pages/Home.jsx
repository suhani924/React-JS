import { useState } from "react";
import { Card, Row, Col, Button, Modal } from "react-bootstrap";
import { Link } from "react-router-dom";


function Home({ initialBooks, addedBooks }) {
  const [selectedBook, setSelectedBook] = useState(null);
  const [show, setShow] = useState(false);

  const handleShow = (book) => { setSelectedBook(book); setShow(true); };
  const handleClose = () => setShow(false);

  const books = [...initialBooks, ...addedBooks];

  const truncateText = (text, wordLimit = 20) => {
    const words = text.split(" ");
    if (words.length <= wordLimit) return text;
    return words.slice(0, wordLimit).join(" ") + "...";
  };

  return (
    <div className="mt-4">
      <h2 className="mb-4">Book List</h2>
      <Row>
        {books.map(book => (
          <Col key={book.id} sm={12} md={4} className="mb-3">
            <Card style={{ width: "350px" }}>
              <Card.Img variant="top" src={book.imgurl} style={{ height: "450px", objectFit: "cover" }} />
              <Card.Body>
                <Card.Title>{book.title}</Card.Title>
                <Card.Text><strong>Author:</strong> {book.author}</Card.Text>
                <Card.Text style={{ fontSize: "0.9rem" }}>{truncateText(book.details, 20)}</Card.Text>
                <Button variant="primary" onClick={() => handleShow(book)}>View Details</Button>
                <Link to={`/book/${book.id}`} className="btn btn-success ms-2">Go to Detail Page</Link>
              </Card.Body>
            </Card>
          </Col>
        ))}
      </Row>

      {selectedBook && (
        <Modal show={show} onHide={handleClose} size="lg">
          <Modal.Header closeButton><Modal.Title>{selectedBook.title}</Modal.Title></Modal.Header>
          <Modal.Body>
            <img src={selectedBook.imgurl} style={{ width: "100%", marginBottom: "10px" }} />
            <p><strong>Author:</strong> {selectedBook.author}</p>
            <p><strong>Publisher:</strong> {selectedBook.publisher || "-"}</p>
            <p><strong>Price:</strong> {selectedBook.price || "-"}</p>
            <p><strong>Type:</strong> {selectedBook.type || "-"}</p>
            <p>{selectedBook.details}</p>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={handleClose}>Close</Button>
          </Modal.Footer>
        </Modal>
      )}
    </div>
  );
}

export default Home;