import { useState } from "react";
import { Container, Form, Button } from "react-bootstrap";
import { useNavigate } from "react-router-dom";

function Add({ addNewBook }) {
  const navigate = useNavigate();
  const [book, setBook] = useState({
    id: "",
    title: "",
    author: "",
    publisher: "",
    price: "",
    type: "",
    imgurl: "",
    details: ""
  });

  const handleChange = (e) => setBook({ ...book, [e.target.name]: e.target.value });

  const handleSubmit = (e) => {
    e.preventDefault();
    addNewBook(book); 
    setBook({ id: "", title: "", author: "", publisher: "", price: "", type: "", imgurl: "", details: "" });
    navigate("/ViewBook");
  };

  return (
    <Container className="mt-4">
      <h2>Add New Book</h2>
      <Form onSubmit={handleSubmit}>
        <Form.Group className="mb-3"><Form.Label>ID</Form.Label><Form.Control name="id" value={book.id} onChange={handleChange} required /></Form.Group>
        <Form.Group className="mb-3"><Form.Label>Title</Form.Label><Form.Control name="title" value={book.title} onChange={handleChange} required /></Form.Group>
        <Form.Group className="mb-3"><Form.Label>Author</Form.Label><Form.Control name="author" value={book.author} onChange={handleChange} required /></Form.Group>
        <Form.Group className="mb-3"><Form.Label>Publisher</Form.Label><Form.Control name="publisher" value={book.publisher} onChange={handleChange} required /></Form.Group>
        <Form.Group className="mb-3"><Form.Label>Price</Form.Label><Form.Control name="price" type="number" value={book.price} onChange={handleChange} required /></Form.Group>
        <Form.Group className="mb-3"><Form.Label>Type</Form.Label>
          <Form.Control as="select" name="type" value={book.type} onChange={handleChange} required>
            <option value="">Select Type</option>
            <option value="Fiction">Fiction</option>
            <option value="Non-Fiction">Non-Fiction</option>
            <option value="Biography">Biography</option>
            <option value="Motivational">Motivational</option>
            <option value="Self-Help">Self-Help</option>
          </Form.Control>
        </Form.Group>
        <Form.Group className="mb-3"><Form.Label>Image URL</Form.Label><Form.Control name="imgurl" value={book.imgurl} onChange={handleChange} required /></Form.Group>
        <Form.Group className="mb-3"><Form.Label>Details</Form.Label><Form.Control as="textarea" rows={6} name="details" value={book.details} onChange={handleChange} required /></Form.Group>
        <Button type="submit" variant="success">Add Book</Button>
      </Form>
    </Container>
  );
}

export default Add;