// src/redux/actions.js

// Action Types
export const FETCH_PRODUCTS = 'FETCH_PRODUCTS';
export const ADD_PRODUCT = 'ADD_PRODUCT';
export const UPDATE_PRODUCT = 'UPDATE_PRODUCT';
export const DELETE_PRODUCT = 'DELETE_PRODUCT';

// JSON Server ka URL
const API_URL = 'http://localhost:5000/products';

// 1. Fetch All Products (GET)
export const fetchProducts = () => {
  return async (dispatch) => {
    const response = await fetch(API_URL);
    const data = await response.json();
    dispatch({ type: FETCH_PRODUCTS, payload: data });
  };
};

// 2. Add New Product (POST)
export const addProduct = (product) => {
  return async (dispatch) => {
    const response = await fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(product),
    });
    const data = await response.json();
    dispatch({ type: ADD_PRODUCT, payload: data });
  };
};

// 3. Update Product (PUT)
export const updateProduct = (id, product) => {
  return async (dispatch) => {
    const response = await fetch(`${API_URL}/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(product),
    });
    const data = await response.json();
    dispatch({ type: UPDATE_PRODUCT, payload: data });
  };
};

// 4. Delete Product (DELETE)
export const deleteProduct = (id) => {
  return async (dispatch) => {
    await fetch(`${API_URL}/${id}`, { method: 'DELETE' });
    dispatch({ type: DELETE_PRODUCT, payload: id });
  };
};
