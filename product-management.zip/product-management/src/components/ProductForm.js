// src/components/ProductForm.js
import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { addProduct } from '../redux/actions';
import { useNavigate } from 'react-router-dom';

function ProductForm() {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  // Form fields ka state
  const [formData, setFormData] = useState({
    title: '',
    price: '',
    category: '',
    image: '',
  });

  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Input change handle karo
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  // Form submit karo
  const handleSubmit = (e) => {
    e.preventDefault();

    // Validation - sab fields bharni chahiye
    if (!formData.title || !formData.price || !formData.category || !formData.image) {
      setError('Please fill all fields!');
      return;
    }

    // Product add karo Redux ke through
    dispatch(
      addProduct({
        title: formData.title,
        price: Number(formData.price),
        category: formData.category,
        image: formData.image,
      })
    );

    setSuccess('Product added successfully!');
    setError('');

    // 1.5 second baad ProductList par jao
    setTimeout(() => {
      navigate('/');
    }, 1500);
  };

  return (
    <div className="row justify-content-center">
      <div className="col-md-6">
        <div className="card shadow p-4">
          <h3 className="mb-3"> Add New Product</h3>

          {error && <div className="alert alert-danger">{error}</div>}
          {success && <div className="alert alert-success">{success}</div>}

          <form onSubmit={handleSubmit}>
            <div className="mb-3">
              <label className="form-label">Product Title</label>
              <input
                type="text"
                className="form-control"
                name="title"
                value={formData.title}
                onChange={handleChange}
                placeholder="e.g. Nike Shoes"
              />
            </div>

            <div className="mb-3">
              <label className="form-label">Price (₹)</label>
              <input
                type="number"
                className="form-control"
                name="price"
                value={formData.price}
                onChange={handleChange}
                placeholder="e.g. 999"
              />
            </div>

            <div className="mb-3">
              <label className="form-label">Category</label>
              <select
                className="form-select"
                name="category"
                value={formData.category}
                onChange={handleChange}
              >
                <option value="">Select Category</option>
                <option value="Clothing">Clothing</option>
                <option value="Footwear">Footwear</option>
                <option value="Electronics">Electronics</option>
                <option value="Accessories">Accessories</option>
                <option value="Other">Other</option>
              </select>
            </div>

            <div className="mb-3">
              <label className="form-label">Image URL</label>
              <input
                type="text"
                className="form-control"
                name="image"
                value={formData.image}
                onChange={handleChange}
                placeholder="https://example.com/image.jpg"
              />
            </div>

            <div className="d-flex gap-2">
              <button type="submit" className="btn btn-primary">
                Add Product
              </button>
              <button
                type="button"
                className="btn btn-secondary"
                onClick={() => navigate('/')}
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

export default ProductForm;
