// src/components/ProductList.js
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchProducts } from '../redux/actions';
import ProductItem from './ProductItem';

function ProductList() {
  const dispatch = useDispatch();

  // Redux store se products lo
  const products = useSelector((state) => state.products);

  // Search, Filter, Sort ke liye local state
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All');
  const [sort, setSort] = useState('');

  // Jab page load ho, products fetch karo
  useEffect(() => {
    dispatch(fetchProducts());
  }, [dispatch]);

  // Unique categories nikaalo (All + product categories)
  const categories = ['All', ...new Set(products.map((p) => p.category))];

  // Products filter karo (search + category)
  let filteredProducts = products.filter((p) => {
    const matchSearch = p.title.toLowerCase().includes(search.toLowerCase());
    const matchCategory = category === 'All' || p.category === category;
    return matchSearch && matchCategory;
  });

  // Sort karo (price ke hisab se)
  if (sort === 'low') {
    filteredProducts = [...filteredProducts].sort((a, b) => a.price - b.price);
  } else if (sort === 'high') {
    filteredProducts = [...filteredProducts].sort((a, b) => b.price - a.price);
  }

  return (
    <div>
      <h2 className="mb-4"> All Products</h2>

      {/* Search, Filter, Sort Controls */}
      <div className="row mb-4">
        {/* Search by title */}
        <div className="col-md-4 mb-2">
          <input
            type="text"
            className="form-control"
            placeholder=" Search by name..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        {/* Filter by category */}
        <div className="col-md-4 mb-2">
          <select
            className="form-select"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
          >
            {categories.map((cat) => (
              <option key={cat} value={cat}>
                {cat}
              </option>
            ))}
          </select>
        </div>

        {/* Sort by price */}
        <div className="col-md-4 mb-2">
          <select
            className="form-select"
            value={sort}
            onChange={(e) => setSort(e.target.value)}
          >
            <option value="">Sort by Price</option>
            <option value="low">Price: Low to High</option>
            <option value="high">Price: High to Low</option>
          </select>
        </div>
      </div>

      {/* Products Grid */}
      {filteredProducts.length === 0 ? (
        <div className="alert alert-warning">No products found!</div>
      ) : (
        <div className="row">
          {filteredProducts.map((product) => (
            <div className="col-md-4 mb-4" key={product.id}>
              <ProductItem product={product} />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default ProductList;
