// src/components/ProductList.js
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchProducts } from '../redux/actions';
import ProductItem from './ProductItem';
import { Link } from 'react-router-dom';

function ProductList() {
  const dispatch = useDispatch();
  const products = useSelector((state) => state.products);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All');
  const [sort, setSort] = useState('');

  useEffect(() => {
    dispatch(fetchProducts());
  }, [dispatch]);

  const categories = ['All', ...new Set(products.map((p) => p.category))];

  let filteredProducts = products.filter((p) => {
    const matchSearch = p.title.toLowerCase().includes(search.toLowerCase());
    const matchCategory = category === 'All' || p.category === category;
    return matchSearch && matchCategory;
  });

  if (sort === 'low') filteredProducts = [...filteredProducts].sort((a, b) => a.price - b.price);
  else if (sort === 'high') filteredProducts = [...filteredProducts].sort((a, b) => b.price - a.price);

  return (
    <div>
  
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h4 className="fw-bold mb-0">📦 All Products <span className="badge bg-secondary ms-2">{filteredProducts.length}</span></h4>
        <Link to="/add" className="btn btn-primary btn-sm px-3">+ Add Product</Link>
      </div>

    
      <div className="row g-2 mb-4">
        <div className="col-md-5">
          <input type="text" className="form-control" placeholder="🔍 Search by name..."
            value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
        <div className="col-md-3">
          <select className="form-select" value={category} onChange={(e) => setCategory(e.target.value)}>
            {categories.map((cat) => <option key={cat} value={cat}>{cat}</option>)}
          </select>
        </div>
        <div className="col-md-4">
          <select className="form-select" value={sort} onChange={(e) => setSort(e.target.value)}>
            <option value="">Sort by Price</option>
            <option value="low">⬆️ Price: Low to High</option>
            <option value="high">⬇️ Price: High to Low</option>
          </select>
        </div>
      </div>

   
      {filteredProducts.length === 0 ? (
        <div className="text-center py-5">
          <h5 className="text-muted">No products found! 😕</h5>
        </div>
      ) : (
        <div className="row g-3">
          {filteredProducts.map((product) => (
            <div className="col-md-4 col-sm-6" key={product.id}>
              <ProductItem product={product} />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default ProductList;