// src/components/PrivateRoute.js
import React from 'react';
import { Navigate } from 'react-router-dom';

// Ye component check karta hai ki user login hai ya nahi
// Agar login hai to page dikhao, nahi to Login page par bhejo
function PrivateRoute({ children }) {
  const isLoggedIn = localStorage.getItem('isLoggedIn');

  if (!isLoggedIn) {
    return <Navigate to="/login" />;
  }

  return children;
}

export default PrivateRoute;
